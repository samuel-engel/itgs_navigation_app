
To modify the location marks in the application, do the following:

1)Make sure you are in the application project folder
2)Locate and open the folde itgs_ia
3)Open marks.json in any text editor
4)Add or modify arrays as you wish, perserving the order of information as well as the data type